import numpy as np
from scipy.fftpack import fft
from scipy import signal 

class PEEG_Analyse(object):
    version = '06AUG2017'
    #Ranges in Hertz
    theta_rng = np.array((1.5, 6.0)) 
    delta_rng = np.array((6.0, 8.5))
    alpha_rng = np.array((8.5, 12,5))
    beta_rng  = np.array((12.5, 30))
    gamma_rng = np.array((30, 40))
    
    def __init__(self, data, trigger, fs, start, stop, low = .1, high = 50, order = 3, window = 2):
        self.data = data
        self.trigger = trigger
        self.fs = fs
        self.start = start
        self.stop = stop
        self.low = low
        self.high= high
        self.order = order
        self.window = window
        
        self.strt_trigger = self.find_triggers(self.trigger, self.start)
        self.stop_trigger = self.find_triggers(self.trigger, self.stop)
        
        self.data_filt = self.bandpass_signal()
        
        for i in range(0, self.strt_trigger.size):
            tmp = self.split_into_epochs(self.data_filt, 0, self.strt_trigger[i], self.stop_trigger[i])
            if i == 0:
                self.epoched = tmp
            else:
                self.epoched = np.concatenate((self.epoched, tmp))
        
        self.f, self.powerspectra = self.cal_FFT(self.epoched)
        self.powerspectra_mean = self.powerspectra.mean(0)
        
        self.cal_PowerBands()

        
    # return triggers
    def find_triggers(self, channel, value):
        return np.array(np.where(np.diff(channel) == value)).flatten()+1

    # Filtering of data
    def bandpass_signal(self):
        b,a = self.butter_bandpass(self.low,self.high)
        return signal.lfilter(b,a,self.data)
    
    def butter_bandpass(self, lowcut, highcut):
        nyq = 0.5 * self.fs
        low = lowcut / nyq
        high = highcut / nyq
        return signal.butter(self.order, [low, high], btype='band')

    # Opsplitsen in blokken van 2^x samples (2 - 8 sec). Overweeg overlap
    # window in seconds
    # Overlap between 0 and 1
    # start_pos and end_pos are indices
    def split_into_epochs(self, data, overlap, start_pos, end_pos): 
        data = np.array(data)
        N = self.window * self.fs # Determine number of samples 
        duration = end_pos - start_pos
        tmp,it = self.nextpow2(duration)
        if np.abs(duration - tmp) > np.abs(duration - 2**(it-1)):
            duration = 2**(it-1) 
        else:
            duration = tmp
        n_epochs = int(duration / N)
        
        start_indices = np.linspace(start_pos, start_pos + duration, n_epochs + 1,dtype = int)
        start_indices = start_indices[:-1]
        
        epochs = np.zeros([int(n_epochs), N])
        for i in range(0,n_epochs):
            epochs[i,:] = data[start_indices[i]:start_indices[i]+N]
        
        return epochs
        
    def nextpow2(self, i):
        n = 1
        it = 1
        while n < i: 
            n *= 2
            it = it + 1
        return n, (it-1)

    # PSDs    
    def cal_FFT(self, data):
        f, Pxx = signal.periodogram(data, self.fs, scaling ='density') #[(uV^2)/Hz]
        return f, Pxx
    
    def cal_Welch(self, data, start_pos, end_pos):
        return signal.welch(data[start_pos:end_pos], fs=self.fs, nperseg = self.window)

    def cal_PowerBands(self):
        self.theta_pwr = self.__pwr(self.theta_rng)
        self.delta_pwr = self.__pwr(self.delta_rng)
        self.alpha_pwr = self.__pwr(self.alpha_rng)
        self.beta_pwr = self.__pwr(self.beta_rng)
        self.gamma_pwr = self.__pwr(self.gamma_rng)
        
    def print_bands(self):
        print('\tTheta: %.2f [(uV)^2]'% self.theta_pwr)
        print('\tDelta: %.2f [(uV)^2]'% self.delta_pwr)
        print('\tAlpha: %.2f [(uV)^2]'% self.alpha_pwr)
        print('\tBeta: %.2f [(uV)^2]'% self.beta_pwr)
        print('\tGamma: %.2f [(uV)^2]'% self.gamma_pwr)
        
    def __pwr(self, range_band):
        ioi1 = np.array(np.where(range_band[0]<=self.f)).flatten()
        ioi1 = ioi1[0]
        ioi2 = np.array(np.where(range_band[1]<=self.f)).flatten()
        ioi2 = ioi2[0]
        return np.sum(self.powerspectra_mean[ioi1:ioi2]) * (self.f[1]-self.f[0])
    # Check voor artefacten in het EOG - reject epoch
    
