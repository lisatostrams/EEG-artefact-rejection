# -*- coding: utf-8 -*-
import pyedflib
import numpy as np
import matplotlib.pyplot as plt

import script.PEEG_Analyse as Analyse

filename = "D:\\Python_workspace\PharmaCoEEG_Analysis\\data\\S1111O01M01_EyesCO_CHDRXXXX_06JUL2017_151733.EDF"

f = pyedflib.EdfReader(filename)

n = f.signals_in_file
signal_labels = f.getSignalLabels()

fs = f.getSampleFrequency(0)
Ts = 1/fs
nSamples = f.getNSamples()[0]
T  = nSamples * Ts
tt = np.linspace(Ts, T, nSamples)

#Channels of interest for the CHDR1633: FzCz, PzO1, PzO2
Fz = f.readSignal(signal_labels.index('Fz'))
Cz = f.readSignal(signal_labels.index('Cz'))
Pz = f.readSignal(signal_labels.index('Pz'))
O1 = f.readSignal(signal_labels.index('O1'))
O2 = f.readSignal(signal_labels.index('O2'))
EOG = f.readSignal(signal_labels.index('EOG'))

FzCz = Fz - Cz
PzO1 = Pz - O1
PzO2 = Pz - O2

#Find triggers
trigger = f.readSignal(signal_labels.index('Trigger_abs'))
#trigger = f.readSignal(signal_labels.index('Trigger'))



window = 6 #secs
FzCz_closed = Analyse.PEEG_Analyse(FzCz, trigger, fs, 1, 2, .1, 50, 3, window)
FzCz_opened = Analyse.PEEG_Analyse(FzCz, trigger, fs, 4, 8, .1, 50, 3, window)

PzO1_closed = Analyse.PEEG_Analyse(PzO1, trigger, fs, 1, 2, .1, 50, 3, window)
PzO1_opened = Analyse.PEEG_Analyse(PzO1, trigger, fs, 4, 8, .1, 50, 3, window)

PzO2_closed = Analyse.PEEG_Analyse(PzO2, trigger, fs, 1, 2, .1, 50, 3, window)
PzO2_opened = Analyse.PEEG_Analyse(PzO2, trigger, fs, 4, 8, .1, 50, 3, window)


plt.plot(FzCz_closed.f,FzCz_closed.powerspectra_mean)
plt.plot(FzCz_opened.f,FzCz_opened.powerspectra_mean)
plt.xlim(0 ,50)
plt.ylabel(r'PSD $\mathregular{[\frac{\mu V^2}{Hz}]}$')
plt.xlabel('Frequency [Hz]')
plt.legend(('Eyes Closed','Eyes Opened'))
plt.title('FzCz')

plt.plot(PzO1_closed.f,PzO1_closed.powerspectra_mean)
plt.plot(PzO1_opened.f,PzO1_opened.powerspectra_mean)
plt.xlim(0 ,50)
plt.ylabel(r'PSD $\mathregular{[\frac{\mu V^2}{Hz}]}$')
plt.xlabel('Frequency [Hz]')
plt.legend(('Eyes Closed','Eyes Opened'))
plt.title('PzO1')

plt.plot(PzO2_closed.f,PzO2_closed.powerspectra_mean)
plt.plot(PzO2_opened.f,PzO2_opened.powerspectra_mean)
plt.xlim(0 ,50)
plt.ylabel(r'PSD $\mathregular{[\frac{\mu V^2}{Hz}]}$')
plt.xlabel('Frequency [Hz]')
plt.legend(('Eyes Closed','Eyes Opened'))
plt.title('PzO2')

print('FzCz closed:')
FzCz_closed.print_bands()
print('\nFzCz opened:')
FzCz_opened.print_bands()

print('\nPzO1 closed:')
PzO1_closed.print_bands()
print('\nPzO1 opened:')
PzO1_opened.print_bands()

print('\nPzO2 closed:')
PzO2_closed.print_bands()
print('\nPzO2 opened:')
PzO2_opened.print_bands()
